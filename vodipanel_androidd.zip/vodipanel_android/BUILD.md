# Build Vodipanel APK
1. Install Android Studio (Koala+) -> Open this folder -> let Gradle sync.
2. Edit app/build.gradle.kts: PANEL_URL = your domain.
3. Put libbox.aar in app/libs/ and finish LibboxCore.kt (see comments).
4. Build > Build Bundle(s)/APK(s) > Build APK(s)   (debug APK for testing)
   Release: Build > Generate Signed App Bundle/APK > APK > create keystore > release.
Command line: ./gradlew assembleRelease  -> app/build/outputs/apk/release/
