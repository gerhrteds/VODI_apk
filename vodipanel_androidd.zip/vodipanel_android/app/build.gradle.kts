plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "app.vodipanel"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.vodipanel"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // panel domain
        buildConfigField("String", "PANEL_URL", "\"https://apk.vodisnapp.ir\"")
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    buildFeatures { compose = true; buildConfig = true }
    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
            signingConfig = signingConfigs.getByName("debug") // replace with your release key (see BUILD.md)
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // sing-box core (build libbox.aar yourself, see BUILD.md) -> put it in app/libs/
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar", "*.jar"))))

    // Tor + Snowflake (verify latest versions on Maven Central / JitPack before building):
    // implementation("info.guardianproject:tor-android:0.4.8.12")
    // implementation("info.guardianproject:jtorctl:0.4.5.7")
    // implementation("com.github.guardianproject:IPtProxy:<latest>")
}
