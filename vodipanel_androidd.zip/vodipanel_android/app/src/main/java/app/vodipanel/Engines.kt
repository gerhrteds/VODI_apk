package app.vodipanel

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * An Engine prepares a complete sing-box config (JSON string) whose outbound reaches the internet
 * through one circumvention core. The single TUN/VPN layer (LibboxCore) then runs that config.
 * Controller tries engines in order and falls back automatically.
 */
interface Engine {
    val id: String
    suspend fun prepare(ctx: Context): String?   // null = this engine is unavailable right now
    suspend fun stop() {}
}

private fun baseConfig(dns: String, outbound: JSONObject): String = JSONObject().apply {
    put("log", JSONObject().put("level", "warn"))
    put("dns", JSONObject().put("servers", JSONArray().put(
        JSONObject().put("tag", "remote").put("address", dns).put("detour", "proxy"))))
    put("inbounds", JSONArray().put(JSONObject()
        .put("type", "tun").put("tag", "tun-in")
        .put("address", JSONArray().put("172.19.0.1/30"))
        .put("auto_route", true).put("strict_route", true).put("stack", "mixed")))
    put("outbounds", JSONArray()
        .put(outbound.put("tag", "proxy"))
        .put(JSONObject().put("type", "direct").put("tag", "direct")))
    put("route", JSONObject().put("auto_detect_interface", true).put("final", "proxy")
        .put("rules", JSONArray()
            .put(JSONObject().put("action", "sniff"))
            .put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
            .put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))))
}.toString()

/** Owner servers via your domain: https://DOMAIN/sub/<token> already returns a full config. */
class PanelEngine : Engine {
    override val id = "panel"
    override suspend fun prepare(ctx: Context): String? {
        if (Prefs.subToken.isBlank()) return null
        val res = Api.request("/sub/${Prefs.subToken}")
        return JSONObject(res).getJSONObject("config").toString()
    }
}

/** Free Tor + Snowflake: start tor, then expose its local SOCKS port to the TUN layer. */
class TorEngine : Engine {
    override val id = "tor-snowflake"
    override suspend fun prepare(ctx: Context): String? {
        // TODO (needs tor-android + IPtProxy dependencies, see build.gradle.kts):
        //  1. IPtProxy.startSnowflake(...)  -> local port for the pluggable transport
        //  2. start Tor with: UseBridges 1, Bridge snowflake ..., ClientTransportPlugin ...
        //  3. wait for bootstrap 100%  -> SOCKS on 127.0.0.1:9050
        val socksReady = false
        if (!socksReady) return null
        val out = JSONObject().put("type", "socks").put("server", "127.0.0.1").put("server_port", 9050)
        return baseConfig(Prefs.dns, out)
    }
}

object VodiController {
    suspend fun engines(): List<Engine> = buildList {
        if (Prefs.useOwnerServers) add(PanelEngine())
        if (Prefs.useTor) add(TorEngine())
    }
}
