package app.vodipanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import kotlinx.coroutines.*

class VodiVpnService : VpnService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var active: Engine? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { shutdown(); return START_NOT_STICKY }
        startForeground(1, notification())
        job?.cancel()
        job = scope.launch {
            VodiState.status.value = Status.CONNECTING
            for (e in VodiController.engines()) {
                VodiState.message.value = e.id
                val cfg = runCatching { e.prepare(this@VodiVpnService) }.getOrNull() ?: continue
                if (LibboxCore.start(this@VodiVpnService, cfg)) {
                    active = e; VodiState.status.value = Status.ON; return@launch
                }
            }
            VodiState.status.value = Status.ERROR
            VodiState.message.value = "no engine available"
            stopSelf()
        }
        return START_STICKY
    }

    private fun shutdown() {
        job?.cancel()
        runBlocking { active?.stop() }
        LibboxCore.stop()
        VodiState.status.value = Status.OFF
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onRevoke() = shutdown()
    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vodi", "Vodipanel", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "vodi").setContentTitle("Vodipanel")
            .setContentText("VPN active").setSmallIcon(android.R.drawable.ic_lock_lock).build()
    }
}
