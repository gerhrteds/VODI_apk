package app.vodipanel

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import java.net.HttpURLConnection
import java.net.URL

enum class Status { OFF, CONNECTING, ON, ERROR }

object VodiState {
    val status = MutableStateFlow(Status.OFF)
    val message = MutableStateFlow("")
}

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("vodi", Context.MODE_PRIVATE) }
    var panelUrl: String
        get() = sp.getString("panel", BuildConfig.PANEL_URL)!!
        set(v) = sp.edit().putString("panel", v.trimEnd('/')).apply()
    var subToken: String                       // customer token (from link or QR)
        get() = sp.getString("token", "")!!
        set(v) = sp.edit().putString("token", v).apply()
    var useTor: Boolean                         // free Tor/Snowflake fallback
        get() = sp.getBoolean("tor", true)
        set(v) = sp.edit().putBoolean("tor", v).apply()
    var useOwnerServers: Boolean
        get() = sp.getBoolean("own", true)
        set(v) = sp.edit().putBoolean("own", v).apply()
    var dns: String
        get() = sp.getString("dns", "https://1.1.1.1/dns-query")!!
        set(v) = sp.edit().putString("dns", v).apply()
    var adminJwt: String
        get() = sp.getString("jwt", "")!!
        set(v) = sp.edit().putString("jwt", v).apply()
}

/** Tiny HTTP helper (no extra dependencies). Call from Dispatchers.IO. */
object Api {
    fun request(path: String, method: String = "GET", body: String? = null, bearer: String? = null): String {
        val c = URL(Prefs.panelUrl + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000; c.readTimeout = 20000
        bearer?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
        if (code !in 200..299) error("HTTP $code $text")
        return text
    }
}

/** multipart upload + bitmap loading helpers */
fun Api.upload(path: String, mime: String, fileName: String, bytes: ByteArray,
               fields: Map<String, String>, bearer: String): String {
    val boundary = "----vodi" + System.nanoTime()
    val c = URL(Prefs.panelUrl + path).openConnection() as HttpURLConnection
    c.requestMethod = "POST"; c.doOutput = true
    c.connectTimeout = 15000; c.readTimeout = 60000
    c.setRequestProperty("Authorization", "Bearer $bearer")
    c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
    c.outputStream.use { o ->
        fields.forEach { (k, v) ->
            o.write("--$boundary\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n".toByteArray())
        }
        o.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"$fileName\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
        o.write(bytes)
        o.write("\r\n--$boundary--\r\n".toByteArray())
    }
    val code = c.responseCode
    val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
    if (code !in 200..299) error("HTTP $code $text")
    return text
}

fun loadBitmap(path: String): android.graphics.Bitmap? = try {
    val u = if (path.startsWith("http")) path else Prefs.panelUrl + path
    URL(u).openStream().use { android.graphics.BitmapFactory.decodeStream(it) }
} catch (e: Exception) { null }

fun flag(cc: String?): String =
    if (cc == null || cc.length != 2) "🌐"
    else String(Character.toChars(0x1F1E6 + (cc[0].uppercaseChar() - 'A'))) +
         String(Character.toChars(0x1F1E6 + (cc[1].uppercaseChar() - 'A')))
