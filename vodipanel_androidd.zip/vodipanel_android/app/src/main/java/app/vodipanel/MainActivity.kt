package app.vodipanel

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn()
    }

    private fun toggle() {
        if (VodiState.status.value == Status.ON || VodiState.status.value == Status.CONNECTING) {
            startService(Intent(this, VodiVpnService::class.java).setAction("STOP"))
        } else {
            val i = VpnService.prepare(this)
            if (i != null) vpnPermission.launch(i) else startVpn()
        }
    }

    private fun startVpn() = startForegroundService(Intent(this, VodiVpnService::class.java))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Root(::toggle) } }
    }
}

@Composable
fun Root(onToggle: () -> Unit) {
    var screen by remember { mutableStateOf("home") }
    Surface(Modifier.fillMaxSize(), color = Color(0xFF0B1020)) {
        when (screen) {
            "home" -> Home(onToggle, { screen = "settings" }, { screen = "owner" })
            "settings" -> Settings { screen = "home" }
            "owner" -> Owner { screen = "home" }
        }
    }
}

class AppCfg(val brand: String, val announcement: String, val logo: Bitmap?, val banners: List<Bitmap>)
class ExitInfo(val ip: String, val cc: String?, val country: String?, val city: String?, val isp: String?)

@Composable
fun Home(onToggle: () -> Unit, openSettings: () -> Unit, openOwner: () -> Unit) {
    val status by VodiState.status.collectAsState()
    val msg by VodiState.message.collectAsState()
    var taps by remember { mutableIntStateOf(0) }
    var cfg by remember { mutableStateOf<AppCfg?>(null) }
    var exit by remember { mutableStateOf<ExitInfo?>(null) }

    // brand + images set by the owner (logo, banners, announcement)
    LaunchedEffect(Unit) {
        cfg = withContext(Dispatchers.IO) {
            try {
                val j = JSONObject(Api.request("/api/app-config"))
                val ban = j.getJSONArray("banners")
                AppCfg(j.optString("brand", "Vodipanel"), j.optString("announcement", ""),
                    j.optJSONObject("logo")?.let { loadBitmap(it.getString("url")) },
                    (0 until ban.length()).mapNotNull { loadBitmap(ban.getJSONObject(it).getString("url")) })
            } catch (e: Exception) { null }
        }
    }
    // once connected: ask the panel what IP/location the world sees (request goes through the tunnel)
    LaunchedEffect(status) {
        exit = null
        if (status == Status.ON) {
            delay(1500)
            exit = withContext(Dispatchers.IO) {
                try {
                    val j = JSONObject(Api.request("/api/myip"))
                    ExitInfo(j.getString("ip"), j.optString("cc").ifBlank { null }, j.optString("country").ifBlank { null },
                        j.optString("city").ifBlank { null }, j.optString("isp").ifBlank { null })
                } catch (e: Exception) { null }
            }
        }
    }

    val color = when (status) { Status.ON -> Color(0xFF22C55E); Status.CONNECTING -> Color(0xFFF59E0B)
        Status.ERROR -> Color(0xFFEF4444); else -> Color(0xFF3B82F6) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            // 7 taps on the logo/name reveals the owner area (customers never find it)
            Row(verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { if (++taps >= 7) { taps = 0; openOwner() } }) {
                cfg?.logo?.let { Image(it.asImageBitmap(), null, Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))); Spacer(Modifier.width(8.dp)) }
                Text(cfg?.brand ?: "Vodipanel", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            TextButton(openSettings) { Text("Settings") }
        }
        if (!cfg?.announcement.isNullOrBlank())
            Text(cfg!!.announcement, color = Color(0xFFFBBF24), modifier = Modifier.padding(top = 8.dp))

        cfg?.banners?.firstOrNull()?.let {
            Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().padding(top = 16.dp).clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.FillWidth)
        }

        Spacer(Modifier.height(40.dp))
        Box(Modifier.size(200.dp).background(color, CircleShape).clickable { onToggle() }, contentAlignment = Alignment.Center) {
            Text(when (status) { Status.ON -> "Disconnect"; Status.CONNECTING -> "..."; else -> "Connect" },
                fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Spacer(Modifier.height(16.dp))
        Text(when (status) { Status.ON -> "Connected"; Status.CONNECTING -> "Connecting via $msg"
            Status.ERROR -> "Failed: $msg"; else -> "Not connected" }, color = Color.White)

        exit?.let {
            Spacer(Modifier.height(20.dp))
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF151C33))) {
                Column(Modifier.padding(16.dp)) {
                    Text("${flag(it.cc)}  ${it.country ?: "Unknown"}${it.city?.let { c -> " · $c" } ?: ""}",
                        color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("IP: ${it.ip}", color = Color(0xFF9CA3AF))
                    it.isp?.let { s -> Text("ISP: $s", color = Color(0xFF9CA3AF)) }
                }
            }
        }
        cfg?.banners?.drop(1)?.forEach {
            Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.FillWidth)
        }
    }
}

@Composable
fun Settings(back: () -> Unit) {
    var token by remember { mutableStateOf(Prefs.subToken) }
    var tor by remember { mutableStateOf(Prefs.useTor) }
    var own by remember { mutableStateOf(Prefs.useOwnerServers) }
    var dns by remember { mutableStateOf(Prefs.dns) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold)
        OutlinedTextField(token, { token = it }, label = { Text("Subscription code") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(own, { own = it }); Spacer(Modifier.width(8.dp)); Text("Use Vodipanel servers", color = Color.White) }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(tor, { tor = it }); Spacer(Modifier.width(8.dp)); Text("Free mode (Tor/Snowflake fallback)", color = Color.White) }
        OutlinedTextField(dns, { dns = it }, label = { Text("DNS (DoH)") }, modifier = Modifier.fillMaxWidth())
        Button({ Prefs.subToken = token.trim(); Prefs.useTor = tor; Prefs.useOwnerServers = own; Prefs.dns = dns; back() }) { Text("Save") }
    }
}

@Composable
fun Owner(back: () -> Unit) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var logged by remember { mutableStateOf(Prefs.adminJwt.isNotBlank()) }
    var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("banner") }; var link by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }; var ann by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }; var json by remember { mutableStateOf("") }
    var cname by remember { mutableStateOf("") }; var days by remember { mutableStateOf("30") }; var gb by remember { mutableStateOf("") }

    fun call(block: suspend () -> String) = scope.launch {
        out = try { withContext(Dispatchers.IO) { block() } } catch (e: Exception) { "Error: ${e.message}" }
    }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) call {
            val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val mime = ctx.contentResolver.getType(uri) ?: "image/png"
            Api.upload("/api/admin/images", mime, "image", bytes, mapOf("kind" to kind, "link" to link), Prefs.adminJwt)
        }
    }
    val pickProxyFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) call {
            val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            Api.upload("/api/admin/import", "text/plain", "proxies.txt", bytes, mapOf("name_prefix" to "px"), Prefs.adminJwt)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Owner panel", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold)
        if (!logged) {
            OutlinedTextField(user, { user = it }, label = { Text("Username") })
            OutlinedTextField(pass, { pass = it }, label = { Text("Password") })
            Button({ call {
                val r = Api.request("/api/admin/login", "POST", JSONObject().put("username", user).put("password", pass).toString())
                Prefs.adminJwt = JSONObject(r).getString("token"); logged = true; "Logged in"
            } }) { Text("Login") }
        } else {
            Text("Proxy / IP list (txt file)", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("one per line: ip:port · socks5://user:pass@ip:port · http://ip:port · ip:port:user:pass", color = Color(0xFF9CA3AF), fontSize = 12.sp)
            Button({ pickProxyFile.launch("text/*") }) { Text("Upload file & scan") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ call { val j = JSONObject(Api.request("/api/admin/scan-status", bearer = Prefs.adminJwt))
                    "Scan: ${j.getInt("done")}/${j.getInt("total")}  ok=${j.getInt("ok")} dead=${j.getInt("dead")}  running=${j.getBoolean("running")}" } }) { Text("Scan status") }
                Button({ call { Api.request("/api/admin/rescan", "POST", bearer = Prefs.adminJwt) } }) { Text("Rescan all") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ call {
                    val a = JSONArray(Api.request("/api/admin/servers", bearer = Prefs.adminJwt))
                    (0 until a.length()).joinToString("\n") { i -> a.getJSONObject(i).let { s ->
                        "${flag(s.optString("cc"))} ${s.optString("country")} ${s.optString("city")} · ${s.optString("host")}:${s.optInt("port")} · " +
                        (if (s.isNull("latency_ms")) "—" else "${s.getInt("latency_ms")}ms") + " · ${s.optString("status")} · ${s.optString("isp")}" } }
                } }) { Text("Servers") }
                Button({ call { Api.request("/api/admin/servers", "DELETE", bearer = Prefs.adminJwt) } }) { Text("Delete dead") }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Name (single server)") })
            OutlinedTextField(json, { json = it }, label = { Text("sing-box outbound JSON (vless/hysteria2/...)") }, modifier = Modifier.fillMaxWidth())
            Button({ call { Api.request("/api/admin/servers", "POST",
                JSONObject().put("name", name).put("outbound", JSONObject(json)).toString(), Prefs.adminJwt) } }) { Text("Add server") }

            HorizontalDivider()
            Text("Images shown in the app", color = Color.White, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("logo", "banner", "background").forEach { k ->
                    FilterChip(kind == k, { kind = k }, label = { Text(k) })
                }
            }
            OutlinedTextField(link, { link = it }, label = { Text("Link when tapped (optional)") }, modifier = Modifier.fillMaxWidth())
            Button({ pickImage.launch("image/*") }) { Text("Choose image & upload") }
            OutlinedTextField(brand, { brand = it }, label = { Text("App name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(ann, { ann = it }, label = { Text("Announcement text") }, modifier = Modifier.fillMaxWidth())
            Button({ call { Api.request("/api/admin/settings", "POST",
                JSONObject().apply { if (brand.isNotBlank()) put("brand", brand); put("announcement", ann) }.toString(), Prefs.adminJwt) } }) { Text("Save texts") }

            HorizontalDivider()
            Text("New customer", color = Color.White, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(cname, { cname = it }, label = { Text("Name") }, modifier = Modifier.weight(2f))
                OutlinedTextField(days, { days = it }, label = { Text("Days") }, modifier = Modifier.weight(1f))
                OutlinedTextField(gb, { gb = it }, label = { Text("GB") }, modifier = Modifier.weight(1f))
            }
            Button({ call {
                val b = JSONObject().put("name", cname).put("days", days.toInt()).apply { gb.toDoubleOrNull()?.let { put("quota_gb", it) } }
                Api.request("/api/admin/customers", "POST", b.toString(), Prefs.adminJwt)
            } }) { Text("Create customer") }
            TextButton({ Prefs.adminJwt = ""; logged = false }) { Text("Logout") }
        }
        Text(out, color = Color(0xFF9CA3AF), fontSize = 12.sp)
        TextButton(back) { Text("Back") }
    }
}
