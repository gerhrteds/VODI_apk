package app.vodipanel

import android.net.VpnService

/**
 * The only place that touches the native sing-box library (libbox.aar).
 * Implement it by copying the PlatformInterface wrapper from the open-source
 * sing-box-for-android project (SagerNet/sing-box-for-android: bg/PlatformInterfaceWrapper.kt)
 * - it implements openTun() using VpnService.Builder and hands the fd to libbox.
 */
object LibboxCore {
    fun start(service: VpnService, configJson: String): Boolean {
        // io.nekohasekai.libbox.Libbox.setup(...)
        // val svc = Libbox.newService(configJson, PlatformInterfaceWrapper(service))
        // svc.start(); this.svc = svc; return true
        return false   // <- replace after adding libbox.aar
    }
    fun stop() {
        // svc?.close()
    }
}
